// HMOOD__TG@i_8_f
 

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
 

void UCommon_DragDrop_Item_C::OnTestDragLeave__DelegateSignature()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnTestDragLeave__DelegateSignature");

	UCommon_DragDrop_Item_C_OnTestDragLeave__DelegateSignature_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 

void UCommon_DragDrop_Item_C::OnTestDragEnter__DelegateSignature()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnTestDragEnter__DelegateSignature");

	UCommon_DragDrop_Item_C_OnTestDragEnter__DelegateSignature_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 

void UCommon_DragDrop_Item_C::OnItemTouchMoved__DelegateSignature()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnItemTouchMoved__DelegateSignature");

	UCommon_DragDrop_Item_C_OnItemTouchMoved__DelegateSignature_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 

void UCommon_DragDrop_Item_C::OnItemTouchEnded__DelegateSignature()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnItemTouchEnded__DelegateSignature");

	UCommon_DragDrop_Item_C_OnItemTouchEnded__DelegateSignature_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 

void UCommon_DragDrop_Item_C::OnItemTouchStarted__DelegateSignature()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnItemTouchStarted__DelegateSignature");

	UCommon_DragDrop_Item_C_OnItemTouchStarted__DelegateSignature_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 
 
 

void UCommon_DragDrop_Item_C::OnDragSuccess__DelegateSignature(class UCommon_DragDrop_Data_C* Operation)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnDragSuccess__DelegateSignature");

	UCommon_DragDrop_Item_C_OnDragSuccess__DelegateSignature_Params params;
	params.Operation = Operation;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 

void UCommon_DragDrop_Item_C::OnDragClicked__DelegateSignature()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnDragClicked__DelegateSignature");

	UCommon_DragDrop_Item_C_OnDragClicked__DelegateSignature_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 
 
 
 

void UCommon_DragDrop_Item_C::OnDragReadyToShape__DelegateSignature(class UWidget* generatedWidget, class UCommon_DragDrop_Data_C* dragOperation)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnDragReadyToShape__DelegateSignature");

	UCommon_DragDrop_Item_C_OnDragReadyToShape__DelegateSignature_Params params;
	params.generatedWidget = generatedWidget;
	params.dragOperation = dragOperation;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 
 
 

void UCommon_DragDrop_Item_C::OnDragCanceled__DelegateSignature(class UCommon_DragDrop_Data_C* Operation)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Common_DragDrop_Item.Common_DragDrop_Item_C.OnDragCanceled__DelegateSignature");

	UCommon_DragDrop_Item_C_OnDragCanceled__DelegateSignature_Params params;
	params.Operation = Operation;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


}

